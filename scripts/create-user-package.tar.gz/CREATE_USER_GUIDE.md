# Create User with Credits - Quick Guide

## 📋 **What You Need**

1. Local Supabase running (`supabase start`)
2. Python 3 installed
3. `.env` file configured with `SUPABASE_URL` and `SUPABASE_KEY`

---

## 🚀 **Quick Start**

### **1. Create User with Default Settings (1000 credits)**

```bash
python3 scripts/create_user_with_credits.py
```

This creates a user with:
- Auto-generated email and username
- 1000 credits
- Active subscription
- API key with full permissions

### **2. Create User with Custom Details**

```bash
python3 scripts/create_user_with_credits.py \
  --email "user@example.com" \
  --username "myuser" \
  --credits 5000
```

---

## 📊 **Example Output**

```
================================================================================
🎉 USER CREATED SUCCESSFULLY!
================================================================================

👤 USER DETAILS:
   User ID:          1
   Username:         admin
   Email:            admin@gatewayz.local
   Credits:          1000.00
   Subscription:     active
   Status:           active

🔐 API KEY:
   API Key ID:       1
   API Key:          gw_live_B5L2tg34ftMWbHCBaj6a5pAEgAJ43puYVDA5_toE-WQ
   Environment:      live
   Permissions:      Full Access (*)

================================================================================
```

---

## 🔧 **Available Options**

| Option | Description | Default |
|--------|-------------|---------|
| `--email` | User email address | Auto-generated |
| `--username` | Username | Auto-generated |
| `--credits` | Initial credit balance | 1000 |

---

## 🧪 **Test the Created User**

```bash
# Save the API key from the output
export API_KEY="gw_live_..."

# Test chat endpoint
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "gpt-3.5-turbo", "messages": [{"role": "user", "content": "Hello!"}]}'

# Check credits
curl http://localhost:8000/v1/users/me \
  -H "Authorization: Bearer $API_KEY"
```

---

## 🔍 **Verify in Database**

```bash
# Connect to database
psql postgresql://postgres:postgres@127.0.0.1:54322/postgres

# Check user
SELECT id, username, email, credits, subscription_status
FROM users
WHERE email = 'admin@gatewayz.local';

# Check API key
SELECT id, key_name, environment_tag, is_active
FROM api_keys_new
WHERE user_id = 1;
```

---

## ❓ **Troubleshooting**

### **Error: "SUPABASE_URL not set"**

Make sure:
1. You're in the project root directory
2. `.env` file exists with these variables:
   ```env
   SUPABASE_URL=http://127.0.0.1:54321
   SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   ```

### **Error: "Failed to create user"**

Check Supabase is running:
```bash
supabase status
```

If not running:
```bash
supabase start
```

### **Error: "User already exists"**

The email must be unique. Use a different email or delete the existing user first.

---

## 📚 **Common Use Cases**

### **Create Multiple Test Users**

```bash
# User 1
python3 scripts/create_user_with_credits.py \
  --email "test1@example.com" \
  --username "test1" \
  --credits 100

# User 2
python3 scripts/create_user_with_credits.py \
  --email "test2@example.com" \
  --username "test2" \
  --credits 500

# User 3 (VIP with lots of credits)
python3 scripts/create_user_with_credits.py \
  --email "vip@example.com" \
  --username "vip" \
  --credits 10000
```

### **Bulk Creation from CSV**

```bash
# Create users.csv with: email,username,credits
# Then:
while IFS=, read -r email username credits; do
  python3 scripts/create_user_with_credits.py \
    --email "$email" \
    --username "$username" \
    --credits "$credits"
done < users.csv
```

---

## 🔐 **Security Notes**

⚠️ **Important:**
- Keep API keys secure
- Don't commit them to git
- Use different keys for production
- Rotate keys regularly

---

## 📞 **Need Help?**

If you encounter issues:

1. Check Supabase is running: `supabase status`
2. Verify `.env` file exists and has correct values
3. Make sure you're in the project root directory
4. Check database connection:
   ```bash
   psql postgresql://postgres:postgres@127.0.0.1:54322/postgres -c "SELECT 1;"
   ```

---

## 📄 **Script Output Format**

The script returns both:
1. **Human-readable output** (formatted text)
2. **JSON output** (for automation/scripting)

Example JSON output:
```json
{
  "user": {
    "id": 1,
    "username": "admin",
    "email": "admin@gatewayz.local",
    "credits": 1000.0,
    "privy_user_id": "user_1764206292",
    "subscription_status": "active"
  },
  "api_key": {
    "id": 1,
    "key": "gw_live_...",
    "environment": "live",
    "permissions": {
      "chat": ["*"],
      "models": ["*"],
      "images": ["*"],
      "admin": ["*"],
      "analytics": ["*"]
    }
  }
}
```

---

**That's it!** Simple, straightforward user creation with credits. 🚀
